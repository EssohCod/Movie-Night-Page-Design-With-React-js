import React from 'react';
import { useState } from 'react'
import MyImage from './person.png';
import HandWave from './handwave.png';
import HandShake from './handshake.png';
import "./page.css";

const Page = () => {
    const [Toggle, dropDown] = useState(false);
  return (
    <section className="landing" id="landing">
            <div className="container">
                <div className="landing-wrapper">
                    <div className="landing-img">
                        <img src={MyImage} alt="Hello" />
                    </div>
                    <div className={Toggle ? "landing-content show-details" : "landing-content"}>
                            <div className="landing__title">
                                <h2>Movie night</h2>
                                <p><img src={HandWave} alt="welcome" />Hosted by <span><b>Elysia</b></span></p>   
                            </div>

                        <div className="guest__bar">
                            <div className="guest__response">
                                <div className="guest__left">
                                    <h4><span><b>14</b></span> responses &nbsp;&nbsp;</h4>
                                    <i className="fa-solid fa-circle"></i>&nbsp;&nbsp;
                                    <a href="#"> see guests</a>
                                </div>
                                <div className="guest__right">
                                    <button><img src={HandShake} alt="" /> Invite</button>
                                </div>
                            </div>
                        </div>

                        <div className="date__bar">
                            <div className="date__icon">
                                <span className="material-symbols-outlined">calendar_month</span>
                            </div>
                            <div className={Toggle ? "date__details show-details" : "date__details"}>
                                <div className="date">
                                    <h3>18 August 6:00PM</h3>
                                    <p>to <span><b>19 August 1:00PM</b></span> UTC+10</p>
                                    {/* <input type="date" id="date" className="date__picker" onClick={() => dropDown(!Toggle)}></input> */}
                                </div>
                                <div className="drop__down">
                                    <i className="uil uil-angle-right-b" onClick={() => dropDown(!Toggle)}></i>
                                </div>
                            </div>
                        </div>

                        <div className="venue__bar">
                            <div className="venue__icon">
                                <i class="fa-solid fa-map-pin"></i>
                            </div>
                            <div className="venue__details">
                                <div className="venue">
                                    <h3>Street name</h3>
                                    <p>301 Rowes Lane, WA 7183</p>
                                </div>
                                <div className="drop__down">
                                <i className="uil uil-angle-right-b" onClick={() => dropDown(!Toggle)}></i>
                                    
                                </div>
                            </div>
                        </div>

                        <div className="link__bar">
                            <div className="link__icon">
                                <span className="material-symbols-outlined">link</span>
                            </div>
                            
                            <div className="link__details">
                                <div className="link">
                                    <h3>Link</h3>
                                    <p>netflix.com</p>
                                </div>
                                <div className="drop__down">
                                    <i class="uil uil-angle-right-b" onClick={() => dropDown(!Toggle)}></i>
                                </div>
                            </div>
                            
                            <div className="comment__bar">
                                <div className="descom">
                                    <div className="description">
                                        <h3>Description</h3>
                                    </div>
                                    <div className="comment">
                                        <h3>Comments.</h3>
                                    </div>
                                </div>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
    </section>
  );
}

export default Page;