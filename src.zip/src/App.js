import './App.css';
import Page from "./component/Page";

function App() {
  return (
    <App>
       <Page />
    </App>
    
  );
}

export default App;
